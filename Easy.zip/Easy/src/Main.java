import java.io.File;

public class Main {
    public static String filePath = "Resources/";
    public static void main(String[] args) {
        StorageManager storageManager = new StorageManager();
        File f = new File(filePath);
        f.mkdir();
        try {
            storageManager.load();
            System.out.println(storageManager.getUsername());

            storageManager.setUsername("Test");
            storageManager.setJsonWebToken("Test2");
            storageManager.save();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}




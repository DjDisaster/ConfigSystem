import java.io.*;
import java.lang.reflect.Field;
import java.util.Arrays;

public interface StorageController {
    FileType getFileType();
    String getFileName();

    default void save() throws IOException, IllegalAccessException {
        File file = new File(Main.filePath + getFileName());
        if (!file.exists()) {
            file.createNewFile();
        }
        BufferedWriter writer = new BufferedWriter(new FileWriter(file));
        StringBuilder out = new StringBuilder();
        System.out.println("A: " + StorageManager.class.getDeclaredFields().length);
        Class<?> clazz = this.getClass();
        for (Field field : clazz.getDeclaredFields()) {
            field.setAccessible(true);
            System.out.println(field.getName() + " " + field.get(this));
            out.append(field.getName() + "," + field.get(this) + "\n");
        }
        System.out.println("B");
        writer.write(out.toString());
        writer.close();
    }

    default void load() throws IOException {
        File file = new File(Main.filePath + getFileName());
        if (!file.exists()) {
            return;
        }
        BufferedReader reader = new BufferedReader(new FileReader(file));
        switch (getFileType()) {
            case FileType.CSV -> reader.lines()
                    .filter(s -> s.split(",").length == 2)
                    .forEach(l -> {
                String[] split = l.split(",");
                try {
                    this.getClass().getDeclaredField(split[0]).setAccessible(true);
                    this.getClass().getDeclaredField(split[0]).set(this, split[1]);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });


        }
    }

}

public enum FileType {
    JSON, CSV
}

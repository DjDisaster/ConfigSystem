public class StorageManager implements StorageController {
    protected String username = "";
    protected String jsonWebToken = "";

    public String getUsername() {
        return username;
    }

    public String getJsonWebToken() {
        return jsonWebToken;
    }

    public void setUsername(String s) {
        username = s;
    }

    public void setJsonWebToken(String s) {
        jsonWebToken = s;
    }

    @Override
    public FileType getFileType() {
        return FileType.CSV;
    }

    @Override
    public String getFileName() {
        return "Storage.csv";
    }


}
